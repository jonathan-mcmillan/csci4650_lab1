To compile:
Use the included Makefile. The following is included in it: "g++ crypt.cpp -o crypt".

To run program:
./crypt <ciphertext> <dictionary>
ciphertext is included in ciphertext.txt
dictionary is included in dictionary.txt

The program should work with other ciphertexts and dictionary.